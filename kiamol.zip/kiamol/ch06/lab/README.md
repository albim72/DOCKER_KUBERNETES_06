# Laboratorium r06

Uruchom aplikację:

```
kubectl apply -f lab/numbers/
```

Pobierz adres URL do otwarcia:

```
kubectl get svc numbers-web -o jsonpath='http://{.status.loadBalancer.ingress[0].*}:8086'
```

> Poprzeglądaj aplikację i spróbuj uzyskać losową liczbę — aplikacja ulegnie awarii.

## Przykładowe rozwiązanie

Dodaj do węzła etykietę RNG:

```
kubectl label node $(kubectl get nodes -o jsonpath='{.items[0].metadata.name}') rng=hw
```

Wdróż nowe zasoby — [Deployment](solution/web-deployment.yaml) dla aplikacji internetowej oraz [DaemonSet](solution/api-daemonset.yaml) dla API:

```
kubectl apply -f lab/solution/
```

> Odśwież przeglądarkę i spradź, czy możesz uzyskać losową liczbę.

Usuń stare zasoby na podstawie ich etykiet:

```
kubectl get all -l kiamol=ch06-lab

kubectl delete all -l kiamol=ch06-lab
```
