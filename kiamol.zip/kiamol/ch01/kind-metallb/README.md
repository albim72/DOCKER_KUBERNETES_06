
# DEPRECATED

Readers found lots of issues using Kind, so the recommendation for your lab environment is either:

* Docker Desktop (on Mac or Windows)
* K3s with Docker (on Linux)

K3s comes with LoadBalancer support built in and works well across different OSes.

See [vagrant-k3s](../vagrant-k3s/README.md) to run K3s in a VM with Vagrant.
