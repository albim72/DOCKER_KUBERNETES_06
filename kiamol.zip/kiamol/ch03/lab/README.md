kubectl apply -f deployments.yaml

kubectl get pods

> Są dwie wersje tej aplikacji internetowej

[Plik services.yaml](./solution/services.yaml) definiuje usługę ClusterIP dla API oraz usługę LoadBalancer dla aplikacji internetowej. Selektor dla usługi internetowej używa dwóch etykiet, aby zapewnić, że uwzględniona zostanie tylko kapsuła v2.

```
kubectl apply -f solution/services.yaml
```

> http://localhost:8088

![](./solution/numbers-web-v2.png)
