# Laboratorium r05

Uruchom aplikację:

```
kubectl apply -f lab/todo-list
```

Sprawdź kapsuły — the proxy ulegnie awarii. Dzienniki powiedzą Ci dlaczego:

```
kubectl get pods

kubectl logs -l app=todo-proxy-lab
```

Proxy wymaga katalogu cache przed uruchomieniem. Trzeba więc zapewnić dwa woluminy:

- wolumin do zamontowania w proxy to `/data/nginx/cache` (wg. informacji z dzienników)
- wolumin do zamontowania w aplikacji to `/data` (na podstawie ustawień zmiennej środowiskowej, opisanych w specyfikacji).

## Przykładowe rozwiązanie

Używam żądań PVC bez zdefiniowanej klasy storage, będą więc korzystać z domyślnego alokatora. Te pliki YAML zawierają specyfikację PVC i zaktualizowane specyfikacje wdrożeń:

- [proxy.yaml](solution/proxy.yaml)
- [web.yaml](solution/web.yaml)

Wdróż aktualizację i sprawdź woluminy:

```
kubectl apply -f lab/solution/

kubectl get pvc

kubectl get pv
```

Znajdź adres URL proxy:

```
kubectl get svc todo-proxy-lab -o jsonpath='http://{.status.loadBalancer.ingress[0].*}:8082'
```

Poprzeglądaj, dodaj kilka elementów, usuń kapsuły:

```
kubectl delete pod -l app=todo-proxy-lab

kubectl delete pod -l app=todo-web-lab
```

Po odświeżeniu przeglądarki powinieneś zobaczyć pierwotne dane.