module.exports = [
  {
    id: 1,
    title: 'DockerCon 2021',
    date: '27.05.2021'
  },
  {
    id: 2,
    title: 'KubeCon Europe 2021',
    date: '16.08.2021'
  },
  {
    id: 3,
    title: 'KubeCon North America 2021',
    date: '23.11.2021'
  }
];