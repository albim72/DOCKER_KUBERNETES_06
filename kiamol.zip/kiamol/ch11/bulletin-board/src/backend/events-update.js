module.exports = [
    {
      id: 1,
      title: 'DockerCon 2021',
      detail: 'Konferencja branżowa na temat techonologii kontenerowej',
      date: '27.05.2021'
    },
    {
      id: 2,
      title: 'KubeCon Europe 2021',
      detail: 'Flagowa konferencja fundacji CNCF',
      date: '16.08.2021'
    },
    {
      id: 3,
      title: 'KubeCon North America 2021',
      detail: 'Flagowa konferencja fundacji CNCF',
      date: '23.11.2021'
    }
  ];