module.exports = [
    {
      id: 1,
      title: 'DockerCon 2021',
      date: '2021-05-27'
    },
    {
      id: 2,
      title: 'KubeCon Europe 2021',
      date: '2021-08-16'
    },
    {
      id: 3,
      title: 'KubeCon North America 2021',
      date: '2021-11-23'
    }
  ];