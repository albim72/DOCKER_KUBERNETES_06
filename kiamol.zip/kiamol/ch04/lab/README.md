kubectl apply -f postgres/

kubectl apply -f solution/

![](./solution/adminer.png)
