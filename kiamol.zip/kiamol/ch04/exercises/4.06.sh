cd /kiamol/ch04 

kubectl apply -f todo-list/configMaps/todo-web-config-dev.yaml
kubectl apply -f todo-list/todo-web-dev.yaml
