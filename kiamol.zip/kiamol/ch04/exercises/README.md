# Exercises

These are scripted versions of the exercises in the chapter.

I used them to smoke-test the exercises on different clusters.

You can use them to save typing time, but be aware that it can take a few seconds for the results of the Kubernetes commands to take effect.

So the output won't always be the same as if you manually run the exercises.