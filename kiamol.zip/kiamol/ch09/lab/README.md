# Laboratorium r09

Uruchom wersję v1 aplikacji:

```
kubectl apply -f lab/v1/
```

Pobierz adres URL i otwórz aplikację:

```
kubectl get svc vweb -o jsonpath='http://{.status.loadBalancer.ingress[0].*}:8090'
```

> v1 to niebieskie wdrożenie

## Przykładowe rozwiązanie

Mój [obiekt v2 Deployment](solution/vweb-v2.yaml) uruchamia kapsuły na podstawie obrazu v2. To nowy obiekt Deployment, a nie aktualizacja istniejącej wersji v1 obiektu Deployment.

Moja [aktualizacja usługu](solution/vweb-service-v2.yaml) zmienia selektor etykiet w istniejącej usłudze, aby wskazywał kapsuły w obiekcie Deployment v2.

```
kubectl apply -f lab/solution/
```

> v2 to zielone wdrożenie

Możesz przeskakiwać między niebieskim a zielonym przez aktualizowanie samej usługi:

```
# Dla v1
kubectl apply -f lab/v1/vweb-service-v1.yaml
```

```
# Dla v2
kubectl apply -f lab/solution/vweb-service-v2.yaml
```

> Twoja przeglądarka może buforować odpowiedź, upewnij się więc, żeby w pełni ją odświeżyć (zwykle za pomocą Ctrl+F5 w systemach Windows lub Cmd+Shift+R w systemach Mac)

## Czyszczenie

Usuń zasoby laboratorium na podstawie ich etykiet:

```
kubectl delete all -l kiamol=ch09-lab
```
