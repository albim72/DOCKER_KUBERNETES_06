# Laboratorium r07

Uruchom aplikację:

```
kubectl apply -f lab/pi/
```

Sprawdź, czy aplikacja nie jest uszkodzona:

```
kubectl describe pod -l app=pi-web
```

> Polecenie rozruchowe dla kontenera aplikacji korzysta ze skryptu, który nie istnieje.

## Przykładowe rozwiązanie

Mój zaktualizowany [obiekt Deployment](solution/web.yaml) dla aplikacji internetowej używa wielu kontenerów.

Kontenery inicjujące:

- kontener inicjujący `init-1` zapisuje plik skryptu rozruchowego w woluminie EmptyDir
- `init-2` czyni skrypt rozruchowy wykonywalnym
- `init-3` zapisuje plik tekstowy z atrapą wersji aplikacji.

Kontener aplikacji:

- montuje wolumin EmptyDir i inicjuje skrypt podczas uruchamiania; serwuje aplikację na porcie 80.

Przyczepa:

- uruchamia prosty serwer NCat HTTP, serwując plik tekstowy z numerem wersji na porcie 8080.


Uruchom akrualizację i otwórz usługę na porcie 8070 dla Pi i na porcie 8071 dla wersji:

```
kubectl apply -f lab/solution/
```

> Nie jest to zbyt efektywne rozwiązanie! To po prostu przykład wykorzystania wielokontenerowych kapsuł.


## Czyszczenie

Usu zasoby laboratorium na podstawie ich etykiet:

```
kubectl get all -l kiamol=ch07-lab

kubectl delete all -l kiamol=ch07-lab
```
