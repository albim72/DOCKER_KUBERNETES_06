# The Service Hotel

Presentation from [Containers Today](https://www.containerstoday.com/sweden/wp-content/uploads/sites/12/2019/12/How-to-Design-a-Container-platform-Sune-Keller-AlmBrand.pdf).

Copied here with kind permission from the author, Docker Captain [Sune Keller](https://twitter.com/sirlatrom).

Thanks Sune :)